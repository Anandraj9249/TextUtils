from django.apps import AppConfig


class TextutilsConfig(AppConfig):
    name = 'textutils'
